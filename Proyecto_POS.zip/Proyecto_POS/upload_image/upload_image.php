<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload de Imagen - Producto</title>
    <link rel="stylesheet" href="./upload_image.css">
  
</head>
<body>
    <?php
    require_once '../config.php';
    
    $message = '';
    $messageType = '';

        
    // // Verificar si hay sesión iniciada
    // if (!isset($_SESSION['user_id'])) {
    //     header('Location: login.php');
    //     exit();
    // }
    
    // Crear directorio de uploads si no existe
    $uploadDir = 'uploads/products/';
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }
    
    // Procesar upload de imagen
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['product_image'])) {
        $targetDir = $uploadDir;
        $imageFileType = strtolower(pathinfo($_FILES["product_image"]["name"], PATHINFO_EXTENSION));
        $newFileName = time() . '.' . $imageFileType;
        $targetFile = $targetDir . $newFileName;
        
        $uploadOk = 1;
        
        // Verificar si es una imagen real
        if (isset($_POST["submit"])) {
            $check = getimagesize($_FILES["product_image"]["tmp_name"]);
            if ($check !== false) {
                $uploadOk = 1;
            } else {
                $message = "El archivo no es una imagen.";
                $messageType = 'error';
                $uploadOk = 0;
            }
        }
        
        // Verificar tamaño del archivo
        if ($_FILES["product_image"]["size"] > 5000000) {
            $message = "El archivo es muy grande. Máximo 5MB.";
            $messageType = 'error';
            $uploadOk = 0;
        }
        
        // Permitir ciertos formatos
        if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
            $message = "Solo se permiten archivos JPG, JPEG, PNG y GIF.";
            $messageType = 'error';
            $uploadOk = 0;
        }
        
        if ($uploadOk == 1) {
            if (move_uploaded_file($_FILES["product_image"]["tmp_name"], $targetFile)) {
                // Actualizar la base de datos si se especificó un producto
                if (!empty($_POST['product_id'])) {
                    try {
                        $pdo = getConnection();
                        $stmt = $pdo->prepare("UPDATE articulo SET imagen = ? WHERE idarticulo = ?");
                        $stmt->execute([$newFileName, $_POST['product_id']]);
                        $message = "Imagen subida y asociada al producto exitosamente.";
                        $messageType = 'success';
                    } catch (Exception $e) {
                        $message = "Imagen subida pero error al actualizar la base de datos.";
                        $messageType = 'error';
                    }
                } else {
                    $message = "Imagen subida exitosamente: " . $newFileName;
                    $messageType = 'success';
                }
            } else {
                $message = "Error al subir el archivo.";
                $messageType = 'error';
            }
        }
    }
    
    // Obtener productos para mostrar
    try {
        $pdo = getConnection();
        $stmt = $pdo->query("SELECT a.*, c.nombre as categoria_nombre FROM articulo a LEFT JOIN categoria c ON a.idcategoria = c.idcategoria WHERE a.condicion = 1 ORDER BY a.nombre");
        $productos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        $productos = [];
    }
    ?>

    <div class="container">
        <div class="header">
            <h1>📸 Upload de Imagen de Producto</h1>
            <p>Sube y gestiona las imágenes de tus productos</p>
        </div>

        <div class="content">
            <?php if ($message): ?>
                <div class="alert alert-<?php echo $messageType; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <form action="" method="post" enctype="multipart/form-data" id="uploadForm">
                <div class="form-group">
                    <label class="form-label">Seleccionar Producto (Opcional)</label>
                    <select name="product_id" class="form-control">
                        <option value="">-- Seleccionar Producto --</option>
                        <?php foreach ($productos as $producto): ?>
                            <option value="<?php echo $producto['idarticulo']; ?>">
                                <?php echo htmlspecialchars($producto['nombre']) . ' - ' . htmlspecialchars($producto['categoria_nombre']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="upload-area" onclick="document.getElementById('fileInput').click()">
                    <div class="upload-icon">📷</div>
                    <div class="upload-text">Haz clic para seleccionar imagen</div>
                    <div class="upload-subtext">o arrastra y suelta aquí</div>
                    <div class="upload-subtext">JPG, PNG, GIF - Máximo 5MB</div>
                </div>

                <input type="file" id="fileInput" name="product_image" class="file-input" accept="image/*" onchange="previewImage(this)">
                
                <div class="preview-area" id="previewArea" style="display: none;">
                    <img id="imagePreview" class="preview-image" src="" alt="Vista previa">
                    <div>
                        <button type="submit" name="submit" class="btn">Subir Imagen</button>
                        <button type="button" class="btn btn-secondary" onclick="clearPreview()">Cancelar</button>
                    </div>
                </div>
            </form>

            <h3 style="margin-top: 40px; color: #333; border-bottom: 2px solid #4ecdc4; padding-bottom: 10px;">
                🛍️ Productos Existentes
            </h3>
            
            <div class="products-grid">
                <?php foreach ($productos as $producto): ?>
                    <div class="product-card">
                        <?php if ($producto['imagen'] && file_exists($uploadDir . $producto['imagen'])): ?>
                            <img src="<?php echo $uploadDir . $producto['imagen']; ?>" alt="<?php echo htmlspecialchars($producto['nombre']); ?>" class="product-image">
                        <?php else: ?>
                            <div style="width: 100%; height: 120px; background: #f0f0f0; border-radius: 10px; display: flex; align-items: center; justify-content: center; margin-bottom: 10px; color: #999;">
                                Sin imagen
                            </div>
                        <?php endif; ?>
                        <div class="product-name"><?php echo htmlspecialchars($producto['nombre']); ?></div>
                        <div class="product-stock">Stock: <?php echo $producto['stock']; ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

   <script src="./upload_image.js"></script>
</body>
</html>