// Drag and drop functionality
const uploadArea = document.querySelector(".upload-area");
const fileInput = document.getElementById("fileInput");

["dragenter", "dragover", "dragleave", "drop"].forEach((eventName) => {
  uploadArea.addEventListener(eventName, preventDefaults, false);
});

function preventDefaults(e) {
  e.preventDefault();
  e.stopPropagation();
}

["dragenter", "dragover"].forEach((eventName) => {
  uploadArea.addEventListener(
    eventName,
    () => uploadArea.classList.add("dragover"),
    false
  );
});

["dragleave", "drop"].forEach((eventName) => {
  uploadArea.addEventListener(
    eventName,
    () => uploadArea.classList.remove("dragover"),
    false
  );
});

uploadArea.addEventListener("drop", handleDrop, false);

function handleDrop(e) {
  const dt = e.dataTransfer;
  const files = dt.files;
  fileInput.files = files;
  previewImage(fileInput);
}

function previewImage(input) {
  if (input.files && input.files[0]) {
    const reader = new FileReader();
    reader.onload = function (e) {
      document.getElementById("imagePreview").src = e.target.result;
      document.getElementById("previewArea").style.display = "block";
    };
    reader.readAsDataURL(input.files[0]);
  }
}

function clearPreview() {
  document.getElementById("previewArea").style.display = "none";
  document.getElementById("fileInput").value = "";
}
