let productIndex = 1;

function addProduct() {
  const container = document.getElementById("products-container");
  const productRow = document.createElement("div");
  productRow.className = "product-row";
  productRow.innerHTML = `
                <div class="form-row">
                    <div class="form-group">
                        <label>Artículo *</label>
                        <select name="productos[${productIndex}][articulo]" class="form-control product-select" required>
                            <option value="">Seleccionar artículo</option>
                            <?php foreach ($articulos as $articulo): ?>
                                <option value="<?php echo $articulo['idarticulo']; ?>">
                                    <?php echo htmlspecialchars($articulo['nombre']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Cantidad *</label>
                        <input type="number" name="productos[${productIndex}][cantidad]" class="form-control quantity" required min="1" value="1">
                    </div>
                    <div class="form-group">
                        <label>Precio Compra *</label>
                        <input type="number" name="productos[${productIndex}][precio_compra]" class="form-control price-buy" required step="0.01" min="0">
                    </div>
                    <div class="form-group">
                        <label>Precio Venta *</label>
                        <input type="number" name="productos[${productIndex}][precio_venta]" class="form-control price-sell" required step="0.01" min="0">
                    </div>
                    <div class="form-group">
                        <label>&nbsp;</label>
                        <button type="button" class="btn btn-danger" onclick="removeProduct(this)">🗑️</button>
                    </div>
                </div>
            `;
  container.appendChild(productRow);
  productIndex++;
  attachEventListeners();
}

function removeProduct(button) {
  if (document.querySelectorAll(".product-row").length > 1) {
    button.closest(".product-row").remove();
    calculateTotal();
  }
}

function calculateTotal() {
  let subtotal = 0;
  document.querySelectorAll(".product-row").forEach((row) => {
    const quantity = parseFloat(row.querySelector(".quantity").value) || 0;
    const price = parseFloat(row.querySelector(".price-buy").value) || 0;
    subtotal += quantity * price;
  });

  const tax = parseFloat(document.getElementById("tax").value) || 0;
  const total = subtotal + (subtotal * tax) / 100;

  document.getElementById("total").value = total.toFixed(2);
  document.getElementById("display-total").textContent = total.toFixed(2);
}

function attachEventListeners() {
  document.querySelectorAll(".quantity, .price-buy").forEach((input) => {
    input.removeEventListener("input", calculateTotal);
    input.addEventListener("input", calculateTotal);
  });
}

document.addEventListener("DOMContentLoaded", function () {
  attachEventListeners();
  document.getElementById("tax").addEventListener("input", calculateTotal);
  calculateTotal();
});
