<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Compras - NeoPOS</title>
    <link rel="stylesheet" href="./gestion_compras.css">
</head>
<body>
    <?php
     require_once '../config.php';
    $message = '';
    $messageType = '';

        try {
        $pdo = getConnection();
    } catch (Exception $e) {
        // Manejar el error de conexión si ocurre
        die("Error de conexión a la base de datos: " . $e->getMessage());
    }

    // Procesar formulario
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
        if ($_POST['action'] === 'save_purchase') {
            try {
    
                $pdo->beginTransaction();
                
                // Insertar compra
                $stmt = $pdo->prepare("INSERT INTO ingreso (idproveedor, idusuario, tipo_comprobante, serie_comprobante, num_comprobante, fecha_hora, impuesto, total_compra, estado) VALUES (?, ?, ?, ?, ?, NOW(), ?, ?, 'Aceptado')");
                $stmt->execute([
                    $_POST['proveedor'],
                    1, // Usuario por defecto
                    $_POST['tipo_comprobante'],
                    $_POST['serie_comprobante'],
                    $_POST['num_comprobante'],
                    $_POST['impuesto'],
                    $_POST['total_compra']
                ]);
                
                $idingreso = $pdo->lastInsertId();
                
                // Insertar detalles
                foreach ($_POST['productos'] as $index => $producto) {
                    if (!empty($producto['articulo']) && $producto['cantidad'] > 0) {
                        $stmt = $pdo->prepare("INSERT INTO detalle_ingreso (idingreso, idarticulo, cantidad, precio_compra, precio_venta) VALUES (?, ?, ?, ?, ?)");
                        $stmt->execute([
                            $idingreso,
                            $producto['articulo'],
                            $producto['cantidad'],
                            $producto['precio_compra'],
                            $producto['precio_venta']
                        ]);
                        
                        // Actualizar stock
                        $stmt = $pdo->prepare("UPDATE articulo SET stock = stock + ? WHERE idarticulo = ?");
                        $stmt->execute([$producto['cantidad'], $producto['articulo']]);
                    }
                }
                
                $pdo->commit();
                $message = "Compra registrada exitosamente";
                $messageType = 'success';
                
            } catch (Exception $e) {
                $pdo->rollBack();
                $message = "Error al registrar la compra: " . $e->getMessage();
                $messageType = 'error';
            }
        }
    }

    // Obtener datos para formularios
    $proveedores = $pdo->query("SELECT * FROM persona WHERE tipo_persona = 'proveedor'")->fetchAll();
    $articulos = $pdo->query("SELECT * FROM articulo WHERE condicion = 1")->fetchAll();
    ?>

    <div class="container">
        <div class="header">
            <h1>🛒 Nueva Compra</h1>
            <p>Registra una nueva compra en el sistema</p>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-<?php echo $messageType; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <form method="POST" id="purchaseForm">
            <input type="hidden" name="action" value="save_purchase">
            
            <!-- Información General -->
            <div class="form-section">
                <h3>📋 Información General</h3>
                <div class="form-row">
                    <div class="form-group">
                        <label>Proveedor *</label>
                        <select name="proveedor" class="form-control" required>
                            <option value="">Seleccionar proveedor</option>
                            <?php foreach ($proveedores as $proveedor): ?>
                                <option value="<?php echo $proveedor['idpersona']; ?>">
                                    <?php echo htmlspecialchars($proveedor['nombre']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Tipo Comprobante *</label>
                        <select name="tipo_comprobante" class="form-control" required>
                            <option value="">Seleccionar tipo</option>
                            <option value="Factura">Factura</option>
                            <option value="Boleta">Boleta</option>
                            <option value="Ticket">Ticket</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Serie</label>
                        <input type="text" name="serie_comprobante" class="form-control" placeholder="001">
                    </div>
                    <div class="form-group">
                        <label>Número *</label>
                        <input type="text" name="num_comprobante" class="form-control" required placeholder="000001">
                    </div>
                </div>
            </div>

            <!-- Productos -->
            <div class="form-section">
                <h3>📦 Productos</h3>
                <div id="products-container">
                    <div class="product-row">
                        <div class="form-row">
                            <div class="form-group">
                                <label>Artículo *</label>
                                <select name="productos[0][articulo]" class="form-control product-select" required>
                                    <option value="">Seleccionar artículo</option>
                                    <?php foreach ($articulos as $articulo): ?>
                                        <option value="<?php echo $articulo['idarticulo']; ?>">
                                            <?php echo htmlspecialchars($articulo['nombre']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Cantidad *</label>
                                <input type="number" name="productos[0][cantidad]" class="form-control quantity" required min="1" value="1">
                            </div>
                            <div class="form-group">
                                <label>Precio Compra *</label>
                                <input type="number" name="productos[0][precio_compra]" class="form-control price-buy" required step="0.01" min="0">
                            </div>
                            <div class="form-group">
                                <label>Precio Venta *</label>
                                <input type="number" name="productos[0][precio_venta]" class="form-control price-sell" required step="0.01" min="0">
                            </div>
                            <div class="form-group">
                                <label>&nbsp;</label>
                                <button type="button" class="btn btn-danger" onclick="removeProduct(this)">🗑️</button>
                            </div>
                        </div>
                    </div>
                </div>
                <button type="button" class="btn" onclick="addProduct()">➕ Agregar Producto</button>
            </div>

            <!-- Totales -->
            <div class="form-section">
                <h3>💰 Totales</h3>
                <div class="form-row">
                    <div class="form-group">
                        <label>Impuesto (%)</label>
                        <input type="number" name="impuesto" class="form-control" step="0.01" min="0" max="100" value="0" id="tax">
                    </div>
                    <div class="form-group">
                        <label>Total Compra *</label>
                        <input type="number" name="total_compra" class="form-control" step="0.01" min="0" required id="total" readonly>
                    </div>
                </div>
            </div>

            <div class="total-section">
                <h3>Total: $<span id="display-total">0.00</span></h3>
            </div>

            <div style="text-align: center; margin-top: 30px;">
                <button type="submit" class="btn btn-success" style="font-size: 1.2em; padding: 15px 40px;">
                    💾 Guardar Compra
                </button>
                <a href="../historial_compras/historial_compras.php" class="btn" style="margin-left: 15px;">
                    📋 Ver Historial
                </a>
            </div>
        </form>
    </div>

    <script src="./gestion_compras.js"></script>
</body>
</html>