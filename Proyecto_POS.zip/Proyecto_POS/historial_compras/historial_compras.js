// Confirmar antes de anular una compra
function confirmarAnulacion(id) {
  if (confirm("¿Está seguro de que desea anular esta compra?")) {
    window.location.href = "anular_compra.php?id=" + id;
  }
}

// Auto-submit del formulario cuando cambian los filtros
document.addEventListener("DOMContentLoaded", function () {
  const filters = document.querySelectorAll(".filter-control");
  filters.forEach((filter) => {
    if (filter.type === "date" || filter.tagName === "SELECT") {
      filter.addEventListener("change", function () {
        // Opcional: Auto-submit al cambiar filtros
        // this.form.submit();
      });
    }
  });
});

// Limpiar filtros
function limpiarFiltros() {
  window.location.href = window.location.pathname;
}
