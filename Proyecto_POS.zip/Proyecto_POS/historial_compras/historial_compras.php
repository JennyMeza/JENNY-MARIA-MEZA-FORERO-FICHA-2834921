<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historial de Compras - NeoPOS</title>
    <link rel="stylesheet" href="./historial_compras.css">
</head>
<body>
    <?php
    require_once '../config.php';


    // // Verificar si hay sesión iniciada (descomentar y usar si es necesario)
    // if (!isset($_SESSION['user_id'])) {
    //     header('Location: login.php');
    //     exit();
    // }
    
    // Parámetros de filtrado
    $fecha_desde = $_GET['fecha_desde'] ?? '';
    $fecha_hasta = $_GET['fecha_hasta'] ?? '';
    $proveedor = $_GET['proveedor'] ?? '';
    $estado = $_GET['estado'] ?? '';
    
    // Paginación
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $records_per_page = 10;
    $offset = ($page - 1) * $records_per_page;
    
    try {
            $pdo = getConnection(); 
        // Construir consulta con filtros
        $where_conditions = [];
        $params = [];
        
        if (!empty($fecha_desde)) {
            $where_conditions[] = "DATE(i.fecha_hora) >= ?";
            $params[] = $fecha_desde;
        }
        
        if (!empty($fecha_hasta)) {
            $where_conditions[] = "DATE(i.fecha_hora) <= ?";
            $params[] = $fecha_hasta;
        }
        
        if (!empty($proveedor)) {
            $where_conditions[] = "p.nombre LIKE ?";
            $params[] = "%$proveedor%";
        }
        
        if (!empty($estado)) {
            $where_conditions[] = "i.estado = ?";
            $params[] = $estado;
        }
        
        $where_clause = !empty($where_conditions) ? "WHERE " . implode(" AND ", $where_conditions) : "";
        
        // Consulta principal para los ingresos
        $sql = "
            SELECT i.*, p.nombre as proveedor_nombre, u.nombre as usuario_nombre,
                   COUNT(di.idarticulo) as total_articulos,
                   SUM(di.cantidad) as total_cantidad
            FROM ingreso i
            LEFT JOIN persona p ON i.idproveedor = p.idpersona
            LEFT JOIN usuario u ON i.idusuario = u.idusuario
            LEFT JOIN detalle_ingreso di ON i.idingreso = di.idingreso
            $where_clause
            GROUP BY i.idingreso
            ORDER BY i.fecha_hora DESC
            LIMIT $records_per_page OFFSET $offset
        ";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $ingresos = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Contar total de registros para paginación
        $count_sql = "
            SELECT COUNT(DISTINCT i.idingreso) as total
            FROM ingreso i
            LEFT JOIN persona p ON i.idproveedor = p.idpersona
            $where_clause
        ";
        $count_stmt = $pdo->prepare($count_sql);
        $count_stmt->execute($params);
        $total_records = $count_stmt->fetchColumn();
        $total_pages = ceil($total_records / $records_per_page);
        
        // Obtener estadísticas
        $stats_sql = "
            SELECT 
                COUNT(*) as total_compras,
                SUM(total_compra) as total_monto,
                COUNT(CASE WHEN estado = 'Aceptado' THEN 1 END) as compras_aceptadas,
                COUNT(CASE WHEN DATE(fecha_hora) = CURDATE() THEN 1 END) as compras_hoy
            FROM ingreso i
            LEFT JOIN persona p ON i.idproveedor = p.idpersona
            $where_clause
        ";
        $stats_stmt = $pdo->prepare($stats_sql);
        $stats_stmt->execute($params);
        $stats = $stats_stmt->fetch(PDO::FETCH_ASSOC);
        
        // Obtener proveedores para el filtro
        $proveedores_stmt = $pdo->query("SELECT DISTINCT nombre FROM persona WHERE tipo_persona = 'proveedor' ORDER BY nombre");
        $proveedores = $proveedores_stmt->fetchAll(PDO::FETCH_COLUMN);
        
    } catch (Exception $e) {
        // Manejo de errores de base de datos
        error_log("Error en historial_compras.php: " . $e->getMessage()); // Registra el error para depuración
        $ingresos = [];
        $total_records = 0;
        $total_pages = 0;
        $stats = ['total_compras' => 0, 'total_monto' => 0, 'compras_aceptadas' => 0, 'compras_hoy' => 0];
        $proveedores = [];
        // Mensaje de error para el usuario
        echo '<div class="empty-state" style="margin-top: 20px;"><div class="empty-icon">❌</div><h3>Error al cargar los datos</h3><p>Por favor, inténtalo de nuevo más tarde o contacta al soporte.</p></div>';
    }
    ?>

    <div class="container">
        <div class="header">
            <div class="header-left">
                <h1>🛒 Historial de Compras</h1>
                <p>Gestiona y consulta todas las compras realizadas</p>
            </div>
        </div>

        <div class="stats-cards">
            <div class="stat-card">
                <div class="stat-icon">📊</div>
                <div class="stat-number"><?php echo number_format($stats['total_compras']); ?></div>
                <div class="stat-label">Total Compras</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">💰</div>
                <div class="stat-number">$<?php echo number_format($stats['total_monto'], 2); ?></div>
                <div class="stat-label">Monto Total</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">✅</div>
                <div class="stat-number"><?php echo number_format($stats['compras_aceptadas']); ?></div>
                <div class="stat-label">Aceptadas</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">📅</div>
                <div class="stat-number"><?php echo number_format($stats['compras_hoy']); ?></div>
                <div class="stat-label">Hoy</div>
            </div>
        </div>

        <div class="filters">
            <form method="GET" action="" id="filterForm">
                <div class="filters-row">
                    <div class="filter-group">
                        <label class="filter-label">Fecha Desde</label>
                        <input type="date" name="fecha_desde" class="filter-control" value="<?php echo htmlspecialchars($fecha_desde); ?>">
                    </div>
                    <div class="filter-group">
                        <label class="filter-label">Fecha Hasta</label>
                        <input type="date" name="fecha_hasta" class="filter-control" value="<?php echo htmlspecialchars($fecha_hasta); ?>">
                    </div>
                    <div class="filter-group">
                        <label class="filter-label">Proveedor</label>
                        <select name="proveedor" class="filter-control">
                            <option value="">Todos los proveedores</option>
                            <?php foreach ($proveedores as $prov): ?>
                                <option value="<?php echo htmlspecialchars($prov); ?>" <?php echo $proveedor === $prov ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($prov); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label class="filter-label">Estado</label>
                        <select name="estado" class="filter-control">
                            <option value="">Todos los estados</option>
                            <option value="Aceptado" <?php echo $estado === 'Aceptado' ? 'selected' : ''; ?>>Aceptado</option>
                            <option value="Anulado" <?php echo $estado === 'Anulado' ? 'selected' : ''; ?>>Anulado</option>
                            <option value="Pendiente" <?php echo $estado === 'Pendiente' ? 'selected' : ''; ?>>Pendiente</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <button type="submit" class="btn">🔍 Filtrar</button>
                    </div>
                    </div>
            </form>
        </div>

        <div class="content">
            <?php if (!empty($ingresos)): ?>
                <table class="purchases-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Fecha</th>
                            <th>Proveedor</th>
                            <th>Comprobante</th>
                            <th>Total</th>
                            <th>Estado</th>
                            <th>Usuario</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($ingresos as $ingreso): ?>
                            <tr>
                                <td><strong>#<?php echo $ingreso['idingreso']; ?></strong></td>
                                <td><?php echo date('d/m/Y H:i', strtotime($ingreso['fecha_hora'])); ?></td>
                                <td><?php echo htmlspecialchars($ingreso['proveedor_nombre'] ?? 'Sin proveedor'); ?></td>
                                <td>
                                    <?php echo htmlspecialchars($ingreso['tipo_comprobante'] ?? 'N/A'); ?><br>
                                    <small><?php echo htmlspecialchars($ingreso['serie_comprobante'] ?? '') . '-' . htmlspecialchars($ingreso['num_comprobante'] ?? ''); ?></small>
                                </td>
                                <td><strong>$<?php echo number_format($ingreso['total_compra'], 2); ?></strong></td>
                                <td>
                                    <span class="status-badge status-<?php echo strtolower($ingreso['estado']); ?>">
                                        <?php echo htmlspecialchars($ingreso['estado']); ?>
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($ingreso['usuario_nombre'] ?? 'N/A'); ?></td>
                            
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <?php if ($total_pages > 1): ?>
                    <div class="pagination">
                        <?php if ($page > 1): ?>
                            <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>">&laquo; Anterior</a>
                        <?php endif; ?>
                        
                        <?php
                        // Lógica para mostrar solo algunas páginas alrededor de la actual
                        $start_page = max(1, $page - 2);
                        $end_page = min($total_pages, $page + 2);

                        if ($start_page > 1) {
                            echo '<a href="?' . http_build_query(array_merge($_GET, ['page' => 1])) . '">1</a>';
                            if ($start_page > 2) {
                                echo '<span>...</span>';
                            }
                        }

                        for ($i = $start_page; $i <= $end_page; $i++): ?>
                            <?php if ($i == $page): ?>
                                <span class="active"><?php echo $i; ?></span>
                            <?php else: ?>
                                <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>"><?php echo $i; ?></a>
                            <?php endif; ?>
                        <?php endfor; ?>

                        <?php if ($end_page < $total_pages): ?>
                            <?php if ($end_page < $total_pages - 1): ?>
                                <span>...</span>
                            <?php endif; ?>
                            <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $total_pages])); ?>"><?php echo $total_pages; ?></a>
                        <?php endif; ?>
                        
                        <?php if ($page < $total_pages): ?>
                            <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>">Siguiente &raquo;</a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="empty-state">
                    <div class="empty-icon">📦</div>
                    <h3>No se encontraron compras</h3>
                    <p>No hay registros que coincidan con los filtros aplicados.</p>
                    <br>
                    <a href="nueva_compra.php" class="btn">➕ Nueva Compra</a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Verifica si hay algún filtro aplicado en la URL
            const urlParams = new URLSearchParams(window.location.search);
            const hasFilters = urlParams.has('fecha_desde') || urlParams.has('fecha_hasta') || 
                               urlParams.has('proveedor') || urlParams.has('estado');

            if (hasFilters) {
                const filtersRow = document.querySelector('.filters-row');
                if (filtersRow) { // Asegúrate de que el elemento existe
                    const clearButtonDiv = document.createElement('div');
                    clearButtonDiv.className = 'filter-group'; // Añade la clase para que se alinee con otros grupos
                    clearButtonDiv.innerHTML = '<button type="button" class="btn clear-btn" onclick="limpiarFiltros()">🗑️ Limpiar</button>';
                    filtersRow.appendChild(clearButtonDiv);
                }
            }
        });

        function limpiarFiltros() {
            // Redirige a la misma página sin ningún parámetro de filtro en la URL
            window.location.href = window.location.pathname; 
        }
    </script>
</body>
</html>