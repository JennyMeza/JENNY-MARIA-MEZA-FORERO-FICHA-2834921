<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reporte de Ingresos - NeoPOS</title>
    <link rel="stylesheet" href="./reporte_ingresos.css">
</head>
<body>
    <?php
    // Configuración de base de datos
    require_once '../config.php';

    $pdo = getConnection(); 

    
    // // Verificar si hay sesión iniciada (descomentar y usar si es necesario)
    // if (!isset($_SESSION['user_id'])) {
    //     header('Location: login.php');
    //     exit();
    // }

    // Parámetros de filtrado
    $fecha_desde = $_GET['fecha_desde'] ?? date('Y-m-01');
    $fecha_hasta = $_GET['fecha_hasta'] ?? date('Y-m-t');
    // El parámetro $tipo_reporte no se usa en las consultas actuales,
    // pero se mantiene por si se implementan diferentes tipos de reportes.
    $tipo_reporte = $_GET['tipo_reporte'] ?? 'compras'; 

    try {
        // Estadísticas generales
        $stats_sql = "
            SELECT 
                COUNT(*) as total_ingresos,
                SUM(total_compra) as total_compras,
                AVG(total_compra) as promedio_compra,
                COUNT(CASE WHEN DATE(fecha_hora) = CURDATE() THEN 1 END) as ingresos_hoy
            FROM ingreso 
            WHERE DATE(fecha_hora) BETWEEN ? AND ?
        ";
        $stats_stmt = $pdo->prepare($stats_sql);
        $stats_stmt->execute([$fecha_desde, $fecha_hasta]);
        $stats = $stats_stmt->fetch(PDO::FETCH_ASSOC);

        // Reporte detallado por fecha
        $report_sql = "
            SELECT 
                DATE(i.fecha_hora) as fecha,
                COUNT(DISTINCT i.idingreso) as total_ingresos_count,
                SUM(i.total_compra) as total_monto,
                SUM(di.cantidad) as total_productos,
                GROUP_CONCAT(DISTINCT p.nombre SEPARATOR ', ') as proveedores
            FROM ingreso i
            LEFT JOIN detalle_ingreso di ON i.idingreso = di.idingreso
            LEFT JOIN persona p ON i.idproveedor = p.idpersona
            WHERE DATE(i.fecha_hora) BETWEEN ? AND ?
            GROUP BY DATE(i.fecha_hora)
            ORDER BY fecha DESC
        ";
        $report_stmt = $pdo->prepare($report_sql);
        $report_stmt->execute([$fecha_desde, $fecha_hasta]);
        $reportes = $report_stmt->fetchAll(PDO::FETCH_ASSOC);

        // Top proveedores
        $top_proveedores_sql = "
            SELECT 
                p.nombre,
                COUNT(*) as total_compras,
                SUM(i.total_compra) as total_monto
            FROM ingreso i
            LEFT JOIN persona p ON i.idproveedor = p.idpersona
            WHERE DATE(i.fecha_hora) BETWEEN ? AND ?
            GROUP BY p.idpersona, p.nombre
            ORDER BY total_monto DESC
            LIMIT 5
        ";
        $top_stmt = $pdo->prepare($top_proveedores_sql);
        $top_stmt->execute([$fecha_desde, $fecha_hasta]);
        $top_proveedores = $top_stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (Exception $e) {
        // Manejo de errores de base de datos
        error_log("Error en reporte_ingresos.php: " . $e->getMessage()); // Registra el error para depuración
        // Inicializar variables para evitar "Undefined variable" en el HTML
        $stats = ['total_ingresos' => 0, 'total_compras' => 0, 'promedio_compra' => 0, 'ingresos_hoy' => 0];
        $reportes = [];
        $top_proveedores = [];
        // Mensaje de error amigable para el usuario
        echo '<div class="empty-state" style="margin-top: 20px;"><div class="empty-icon">❌</div><h3>Error al cargar los datos del reporte</h3><p>Por favor, inténtalo de nuevo más tarde o contacta al soporte.</p></div>';
    }
    ?>

    <div class="container">
        <div class="header">
            <h1>📊 Reporte de Ingresos</h1>
            <p>Análisis detallado de compras e ingresos del sistema</p>
        </div>

        <div class="stats-cards">
            <div class="stat-card">
                <div class="stat-icon">🛒</div>
                <div class="stat-number"><?php echo number_format($stats['total_ingresos']); ?></div>
                <div class="stat-label">Total Ingresos</div>
            </div>
            <div class="stat-card success">
                <div class="stat-icon">💰</div>
                <div class="stat-number">$<?php echo number_format($stats['total_compras'] ?? 0, 2); ?></div>
                <div class="stat-label">Monto Total</div>
            </div>
            <div class="stat-card warning">
                <div class="stat-icon">📈</div>
                <div class="stat-number">$<?php echo number_format($stats['promedio_compra'] ?? 0, 2); ?></div>
                <div class="stat-label">Promedio por Compra</div>
            </div>
            <div class="stat-card info">
                <div class="stat-icon">📅</div>
                <div class="stat-number"><?php echo number_format($stats['ingresos_hoy']); ?></div>
                <div class="stat-label">Ingresos Hoy</div>
            </div>
        </div>

        <div class="filters">
            <form method="GET" id="reporteFilterForm">
                <div class="filters-row">
                    <div class="filter-group">
                        <label class="filter-label">Fecha Desde</label>
                        <input type="date" name="fecha_desde" class="filter-control" value="<?php echo htmlspecialchars($fecha_desde); ?>">
                    </div>
                    <div class="filter-group">
                        <label class="filter-label">Fecha Hasta</label>
                        <input type="date" name="fecha_hasta" class="filter-control" value="<?php echo htmlspecialchars($fecha_hasta); ?>">
                    </div>
                    <div class="filter-group">
                        <button type="submit" class="btn">🔍 Generar Reporte</button>
                    </div>
                    </div>
            </form>
        </div>

          <h3 style="color: #495057; margin-bottom: 20px;">📅 Reporte por Fechas</h3>
        <?php if (!empty($reportes)): ?>
            <table class="report-table">
                <thead>
                    <tr>
                        <th>Fecha</th>
                        <th># Ingresos</th>
                        <th>Monto Total</th>
                        <th>Total Productos</th>
                        <th>Proveedores Principales</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $total_general_monto = 0;
                    $total_general_ingresos_count = 0;
                    foreach ($reportes as $reporte): 
                        $total_general_monto += $reporte['total_monto'];
                        $total_general_ingresos_count += $reporte['total_ingresos_count'];
                    ?>
                        <tr>
                            <td><strong><?php echo date('d/m/Y', strtotime($reporte['fecha'])); ?></strong></td>
                            <td><?php echo number_format($reporte['total_ingresos_count']); ?></td>
                            <td><strong>$<?php echo number_format($reporte['total_monto'], 2); ?></strong></td>
                            <td><?php echo number_format($reporte['total_productos'] ?? 0); ?></td>
                            <td><?php echo htmlspecialchars(substr($reporte['proveedores'] ?? 'N/A', 0, 50)) . (strlen($reporte['proveedores'] ?? '') > 50 ? '...' : ''); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <tr class="total-row">
                        <td><strong>TOTAL PERÍODO</strong></td>
                        <td><strong><?php echo number_format($total_general_ingresos_count); ?></strong></td>
                        <td><strong>$<?php echo number_format($total_general_monto, 2); ?></strong></td>
                        <td colspan="2"></td> </tr>
                </tbody>
            </table>
        <?php else: ?>
            <div class="empty-state">
                <div class="empty-icon">📋</div>
                <h3>No hay datos de ingresos para mostrar</h3>
                <p>No se encontraron registros de ingresos en el rango de fechas seleccionado.</p>
            </div>
        <?php endif; ?>
    <h3 style="color: #495057; margin: 40px 0 20px 0;">🏆 Top Proveedores</h3>
    
        <?php if (!empty($top_proveedores)): ?>
            <table class="report-table">
                <thead>
                    <tr>
                        <th>Posición</th>
                        <th>Proveedor</th>
                        <th>Total de Compras</th>
                        <th>Monto Total Comprado</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($top_proveedores as $index => $proveedor): ?>
                        <tr>
                            <td><strong>#<?php echo $index + 1; ?></strong></td>
                            <td><?php echo htmlspecialchars($proveedor['nombre'] ?? 'N/A'); ?></td>
                            <td><?php echo number_format($proveedor['total_compras']); ?></td>
                            <td><strong>$<?php echo number_format($proveedor['total_monto'], 2); ?></strong></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="empty-state">
                <div class="empty-icon">🏪</div>
                <h3>No hay proveedores principales para mostrar</h3>
                <p>No se encontraron registros de compras a proveedores en el período seleccionado.</p>
            </div>
        <?php endif; ?>

        <div style="text-align: center; margin-top: 40px; margin-bottom: 20px;">
            <a href="../historial_compras/historial_compras.php" class="btn">📋 Ver Historial de Compras</a>
            <a href="../gestion_compras/gestion_compras.php" class="btn" style="margin-left: 15px;">🛒 Registrar Nueva Compra</a>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const urlParams = new URLSearchParams(window.location.search);
            // Revisa si hay alguno de los parámetros de fecha en la URL
            const hasFilters = urlParams.has('fecha_desde') || urlParams.has('fecha_hasta');

            if (hasFilters) {
                const filtersRow = document.querySelector('.filters-row');
                if (filtersRow) {
                    const clearButtonDiv = document.createElement('div');
                    clearButtonDiv.className = 'filter-group'; 
                    clearButtonDiv.innerHTML = '<button type="button" class="btn clear-btn" onclick="limpiarFiltros()" style="background-color: #dc3545;">🗑️ Limpiar</button>';
                    filtersRow.appendChild(clearButtonDiv);
                }
            }
        });

        function limpiarFiltros() {
            // Elimina todos los parámetros de la URL y recarga la página
            window.location.href = window.location.pathname; 
        }
    </script>
</body>
</html>