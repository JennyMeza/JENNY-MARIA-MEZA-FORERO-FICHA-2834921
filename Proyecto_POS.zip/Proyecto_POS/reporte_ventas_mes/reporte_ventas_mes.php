<?php
// Configuración de base de datos
$host = 'localhost';
$dbname = 'dbsistema';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}

// Parámetros de filtrado
$year = $_GET['year'] ?? date('Y');
$mes_seleccionado = $_GET['mes'] ?? '';

try {
    // Generar datos para los últimos 12 meses
    $ventas_por_mes = [];
    $compras_por_mes = [];
    $meses = [];
    
    for ($i = 11; $i >= 0; $i--) {
        $mes = date('Y-m', strtotime("-$i months"));
        $mes_nombre = date('M Y', strtotime("-$i months"));
        $meses[] = $mes_nombre;
        
        // Ventas del mes - solo datos reales
        $ventas_sql = "SELECT COALESCE(SUM(total_venta), 0) as total FROM venta WHERE DATE_FORMAT(fecha_hora, '%Y-%m') = ?";
        $ventas_stmt = $pdo->prepare($ventas_sql);
        $ventas_stmt->execute([$mes]);
        $ventas_por_mes[] = (float)$ventas_stmt->fetchColumn();
        
        // Compras del mes - solo datos reales
        $compras_sql = "SELECT COALESCE(SUM(total_compra), 0) as total FROM ingreso WHERE DATE_FORMAT(fecha_hora, '%Y-%m') = ?";
        $compras_stmt = $pdo->prepare($compras_sql);
        $compras_stmt->execute([$mes]);
        $compras_por_mes[] = (float)$compras_stmt->fetchColumn();
    }

    // Estadísticas generales
    $total_ventas = array_sum($ventas_por_mes);
    $total_compras = array_sum($compras_por_mes);
    $utilidad = $total_ventas - $total_compras;
    $mejor_mes_ventas = max($ventas_por_mes);
    $indice_mejor_mes = array_search($mejor_mes_ventas, $ventas_por_mes);
    $mejor_mes_nombre = $meses[$indice_mejor_mes] ?? 'N/A';

    // Datos mensuales para tabla
    $datos_mensuales = [];
    for ($i = 0; $i < 12; $i++) {
        $utilidad_mes = $ventas_por_mes[$i] - $compras_por_mes[$i];
        $datos_mensuales[] = [
            'mes' => $meses[$i],
            'ventas' => $ventas_por_mes[$i],
            'compras' => $compras_por_mes[$i],
            'utilidad' => $utilidad_mes
        ];
    }

    // Consultar productos más vendidos
    $productos_sql = "SELECT a.nombre, SUM(dv.cantidad) as total_vendido 
                     FROM detalle_venta dv 
                     INNER JOIN articulo a ON dv.idarticulo = a.idarticulo 
                     INNER JOIN venta v ON dv.idventa = v.idventa 
                     WHERE YEAR(v.fecha_hora) = ? 
                     GROUP BY a.idarticulo, a.nombre 
                     ORDER BY total_vendido DESC 
                     LIMIT 5";
    $productos_stmt = $pdo->prepare($productos_sql);
    $productos_stmt->execute([$year]);
    $productos_top = $productos_stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    // En caso de error, inicializar arrays vacíos
    $meses = [];
    $ventas_por_mes = [];
    $compras_por_mes = [];
    $total_ventas = 0;
    $total_compras = 0;
    $utilidad = 0;
    $mejor_mes_nombre = 'N/A';
    $datos_mensuales = [];
    $productos_top = [];
    $error_message = "Error al consultar datos: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reporte Gráfico de Ventas - NeoPOS</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
    <link rel="stylesheet" href="./reporte_ventas_mes.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📈 Reporte Gráfico de Ventas</h1>
            <p>Análisis visual de ventas y compras por mes - Sistema NeoPOS</p>
        </div>

        <!-- Mostrar error si existe -->
        <?php if (isset($error_message)): ?>
            <div class="error-message">
                <h3>⚠️ Error en la Consulta</h3>
                <p><?php echo htmlspecialchars($error_message); ?></p>
            </div>
        <?php endif; ?>

        <!-- Tarjetas de estadísticas -->
        <div class="stats-cards">
            <div class="stat-card success">
                <div class="stat-icon">💰</div>
                <div class="stat-number">$<?php echo number_format($total_ventas, 0); ?></div>
                <div class="stat-label">Total Ventas (12 meses)</div>
            </div>
            <div class="stat-card warning">
                <div class="stat-icon">🛒</div>
                <div class="stat-number">$<?php echo number_format($total_compras, 0); ?></div>
                <div class="stat-label">Total Compras (12 meses)</div>
            </div>
            <div class="stat-card info">
                <div class="stat-icon">📊</div>
                <div class="stat-number">$<?php echo number_format($utilidad, 0); ?></div>
                <div class="stat-label">Utilidad Bruta</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">🏆</div>
                <div class="stat-number"><?php echo $mejor_mes_nombre; ?></div>
                <div class="stat-label">Mejor Mes</div>
            </div>
        </div>

        <!-- Filtros -->
        <div class="filters">
            <form method="GET">
                <div class="filters-row">
                    <div class="filter-group">
                        <label class="filter-label">Año</label>
                        <select name="year" class="filter-control">
                            <?php for ($i = date('Y'); $i >= 2020; $i--): ?>
                                <option value="<?php echo $i; ?>" <?php echo $year == $i ? 'selected' : ''; ?>>
                                    <?php echo $i; ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label class="filter-label">Mes (Opcional)</label>
                        <select name="mes" class="filter-control">
                            <option value="">Todos los meses</option>
                            <?php 
                            $meses_nombres = [
                                '01' => 'Enero', '02' => 'Febrero', '03' => 'Marzo', '04' => 'Abril',
                                '05' => 'Mayo', '06' => 'Junio', '07' => 'Julio', '08' => 'Agosto',
                                '09' => 'Septiembre', '10' => 'Octubre', '11' => 'Noviembre', '12' => 'Diciembre'
                            ];
                            foreach ($meses_nombres as $num => $nombre): ?>
                                <option value="<?php echo $num; ?>" <?php echo $mes_seleccionado == $num ? 'selected' : ''; ?>>
                                    <?php echo $nombre; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <button type="submit" class="btn">🔍 Actualizar Reporte</button>
                    </div>
                </div>
            </form>
        </div>

        <!-- Gráfico de Ventas vs Compras -->
        <?php if (!empty($meses) && array_sum($ventas_por_mes) > 0): ?>
        <div class="chart-container">
            <h3 class="chart-title">📈 Ventas vs Compras por Mes</h3>
            <div class="chart-wrapper">
                <canvas id="ventasChart"></canvas>
            </div>
        </div>
        <?php else: ?>
        <div class="chart-container">
            <div class="empty-state">
                <div class="empty-icon">📈</div>
                <h3>Sin datos de ventas</h3>
                <p>No se encontraron registros de ventas en el período seleccionado.</p>
            </div>
        </div>
        <?php endif; ?>

        <!-- Gráfico de Utilidad -->
        <?php if (!empty($meses) && (array_sum($ventas_por_mes) > 0 || array_sum($compras_por_mes) > 0)): ?>
        <div class="chart-container">
            <h3 class="chart-title">💹 Utilidad por Mes</h3>
            <div class="chart-wrapper">
                <canvas id="utilidadChart"></canvas>
            </div>
        </div>
        <?php else: ?>
        <div class="chart-container">
            <div class="empty-state">
                <div class="empty-icon">💹</div>
                <h3>Sin datos de utilidad</h3>
                <p>No hay suficientes datos para calcular la utilidad.</p>
            </div>
        </div>
        <?php endif; ?>

        <!-- Gráfico de Productos Top -->
        <?php if (!empty($productos_top)): ?>
        <div class="chart-container">
            <h3 class="chart-title">🏆 Top 5 Productos Más Vendidos</h3>
            <div class="chart-wrapper">
                <canvas id="productosChart"></canvas>
            </div>
        </div>
        <?php else: ?>
        <div class="chart-container">
            <div class="empty-state">
                <div class="empty-icon">🏆</div>
                <h3>Sin datos de productos</h3>
                <p>No se encontraron productos vendidos en el período seleccionado.</p>
            </div>
        </div>
        <?php endif; ?>

        <!-- Tabla de Resumen Mensual -->
        <div class="chart-container">
            <h3 class="chart-title">📋 Resumen Mensual Detallado</h3>
            <?php if (!empty($datos_mensuales)): ?>
                <table class="summary-table">
                    <thead>
                        <tr>
                            <th>Mes</th>
                            <th>Ventas</th>
                            <th>Compras</th>
                            <th>Utilidad</th>
                            <th>Margen %</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($datos_mensuales as $dato): 
                            $margen = $dato['ventas'] > 0 ? (($dato['utilidad'] / $dato['ventas']) * 100) : 0;
                            $clase_utilidad = $dato['utilidad'] > 0 ? 'positive' : ($dato['utilidad'] < 0 ? 'negative' : 'neutral');
                        ?>
                            <tr>
                                <td><strong><?php echo $dato['mes']; ?></strong></td>
                                <td>$<?php echo number_format($dato['ventas'], 0); ?></td>
                                <td>$<?php echo number_format($dato['compras'], 0); ?></td>
                                <td class="<?php echo $clase_utilidad; ?>">
                                    $<?php echo number_format($dato['utilidad'], 0); ?>
                                </td>
                                <td class="<?php echo $clase_utilidad; ?>">
                                    <?php echo number_format($margen, 1); ?>%
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="empty-state">
                    <div class="empty-icon">📊</div>
                    <h3>No hay datos disponibles</h3>
                    <p>No se encontraron datos para el período seleccionado.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // Datos desde PHP
        const datosDB = {
            meses: <?php echo json_encode($meses); ?>,
            ventas: <?php echo json_encode($ventas_por_mes); ?>,
            compras: <?php echo json_encode($compras_por_mes); ?>,
            productos: <?php echo json_encode($productos_top); ?>,
            hayDatos: <?php echo (!empty($meses) && array_sum($ventas_por_mes) > 0) ? 'true' : 'false'; ?>
        };

        // Función para formatear números como moneda
        function formatearMoneda(valor) {
            return '$' + valor.toLocaleString('es-CO');
        }

        // Crear gráfico de ventas vs compras
        function crearGraficoVentas() {
            if (!datosDB.hayDatos) return;
            
            const ctx = document.getElementById('ventasChart');
            if (!ctx) return;

            new Chart(ctx.getContext('2d'), {
                type: 'line',
                data: {
                    labels: datosDB.meses,
                    datasets: [
                        {
                            label: 'Ventas',
                            data: datosDB.ventas,
                            borderColor: 'rgb(40, 167, 69)',
                            backgroundColor: 'rgba(40, 167, 69, 0.1)',
                            borderWidth: 3,
                            fill: true,
                            tension: 0.4
                        },
                        {
                            label: 'Compras',
                            data: datosDB.compras,
                            borderColor: 'rgb(255, 193, 7)',
                            backgroundColor: 'rgba(255, 193, 7, 0.1)',
                            borderWidth: 3,
                            fill: true,
                            tension: 0.4
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        tooltip: {
                            mode: 'index',
                            intersect: false,
                            callbacks: {
                                label: function(context) {
                                    return context.dataset.label + ': ' + formatearMoneda(context.parsed.y);
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    return formatearMoneda(value);
                                }
                            }
                        }
                    }
                }
            });
        }

        // Crear gráfico de utilidad
        function crearGraficoUtilidad() {
            if (!datosDB.hayDatos) return;
            
            const ctx = document.getElementById('utilidadChart');
            if (!ctx) return;

            const utilidadData = datosDB.ventas.map((venta, index) => venta - datosDB.compras[index]);

            new Chart(ctx.getContext('2d'), {
                type: 'bar',
                data: {
                    labels: datosDB.meses,
                    datasets: [{
                        label: 'Utilidad',
                        data: utilidadData,
                        backgroundColor: utilidadData.map(value =>
                            value >= 0 ? 'rgba(40, 167, 69, 0.8)' : 'rgba(220, 53, 69, 0.8)'
                        ),
                        borderColor: utilidadData.map(value =>
                            value >= 0 ? 'rgb(40, 167, 69)' : 'rgb(220, 53, 69)'
                        ),
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return context.dataset.label + ': ' + formatearMoneda(context.parsed.y);
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    return formatearMoneda(value);
                                }
                            }
                        }
                    }
                }
            });
        }

        // Crear gráfico de productos
        function crearGraficoProductos() {
            if (!datosDB.productos || datosDB.productos.length === 0) return;
            
            const ctx = document.getElementById('productosChart');
            if (!ctx) return;

            const productosLabels = datosDB.productos.map(p => p.nombre);
            const productosVentas = datosDB.productos.map(p => parseInt(p.total_vendido));

            new Chart(ctx.getContext('2d'), {
                type: 'doughnut',
                data: {
                    labels: productosLabels,
                    datasets: [{
                        data: productosVentas,
                        backgroundColor: [
                            'rgba(102, 126, 234, 0.8)',
                            'rgba(118, 75, 162, 0.8)',
                            'rgba(40, 167, 69, 0.8)',
                            'rgba(255, 193, 7, 0.8)',
                            'rgba(23, 162, 184, 0.8)'
                        ],
                        borderColor: [
                            'rgb(102, 126, 234)',
                            'rgb(118, 75, 162)',
                            'rgb(40, 167, 69)',
                            'rgb(255, 193, 7)',
                            'rgb(23, 162, 184)'
                        ],
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'right',
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return context.label + ': ' + context.parsed + ' unidades';
                                }
                            }
                        }
                    }
                }
            });
        }

        // Inicializar gráficos cuando el DOM esté listo
        document.addEventListener('DOMContentLoaded', function() {
            console.log('Inicializando gráficos con datos de la base de datos...');
            console.log('Datos disponibles:', datosDB);
            
            // Crear todos los gráficos
            crearGraficoVentas();
            crearGraficoUtilidad();
            crearGraficoProductos();
            
            console.log('Reporte de Ventas NeoPOS cargado correctamente');
        });
    </script>
</body>
</html>