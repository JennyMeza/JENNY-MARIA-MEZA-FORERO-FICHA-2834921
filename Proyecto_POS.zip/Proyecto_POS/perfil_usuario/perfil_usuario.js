function toggleEditForm() {
  const editForm = document.getElementById("editForm");
  editForm.classList.toggle("active");

  if (editForm.classList.contains("active")) {
    editForm.scrollIntoView({ behavior: "smooth" });
  }
}
