<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil de Usuario - NeoPOS</title>
    <link rel="stylesheet" href="./perfil_usuario.css">
</head>
<body>
    <?php
    require_once '../config.php';
    
 
    // // Verificar si hay sesión iniciada (descomentar y usar si es necesario)
    // if (!isset($_SESSION['user_id'])) {
    //     header('Location: login.php');
    //     exit();
    // }
    $message = '';
    $messageType = '';
    
    // Procesar actualización de perfil
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
        try {
            $pdo = getConnection();
            
            $nombre = $_POST['nombre'] ?? '';
            $email = $_POST['email'] ?? '';
            $telefono = $_POST['telefono'] ?? '';
            $direccion = $_POST['direccion'] ?? '';
            
            $stmt = $pdo->prepare("UPDATE usuario SET nombre = ?, email = ?, telefono = ?, direccion = ? WHERE idusuario = ?");
            $stmt->execute([$nombre, $email, $telefono, $direccion, 1]); //aqui necesitas reemplaza el 1 por como obtengas el id de la sesion por ejemplo $_SESSION['user_id']]
            
            // Actualizar sesión
            $_SESSION['user_name'] = $nombre;
            $_SESSION['user_email'] = $email;
            
            $message = "Perfil actualizado exitosamente";
            $messageType = 'success';
        } catch (Exception $e) {
            $message = "Error al actualizar el perfil";
            $messageType = 'error';
        }
    }
    
    // Obtener datos del usuario
    try {
        $pdo = getConnection();
        $stmt = $pdo->prepare("SELECT * FROM usuario WHERE idusuario = ?");
        $stmt->execute([1]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Obtener permisos del usuario
        $stmt = $pdo->prepare("
            SELECT p.nombre, p.idpermiso 
            FROM usuario_permiso up 
            JOIN permiso p ON up.idpermiso = p.idpermiso 
            WHERE up.idusuario = ?
        ");
        $stmt->execute([1]); //aqui necesitas reemplaza el 1 por como obtengas el id de la sesion por ejemplo $_SESSION['user_id']]
        $permisos_usuario = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Obtener todos los permisos disponibles
        $stmt = $pdo->query("SELECT * FROM permiso");
        $todos_permisos = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Obtener estadísticas del usuario
        $stmt = $pdo->prepare("SELECT COUNT(*) as total_ventas FROM venta WHERE idusuario = ?");
        $stmt->execute([1]); //aqui necesitas reemplaza el 1 por como obtengas el id de la sesion por ejemplo $_SESSION['user_id']]
            
        $stats_ventas = $stmt->fetchColumn();
        
        $stmt = $pdo->prepare("SELECT COUNT(*) as total_ingresos FROM ingreso WHERE idusuario = ?");
        $stmt->execute([1]); //aqui necesitas reemplaza el 1 por como obtengas el id de la sesion por ejemplo $_SESSION['user_id']]
            
        $stats_ingresos = $stmt->fetchColumn();
        
    } catch (Exception $e) {
        $usuario = null;
        $permisos_usuario = [];
        $todos_permisos = [];
        $stats_ventas = 0;
        $stats_ingresos = 0;
    }
    
    // Crear array de permisos activos
    $permisos_activos = array_column($permisos_usuario, 'nombre');
    
    // Iconos para permisos
    $iconos_permisos = [
        'ventas' => '💰',
        'compras' => '🛒',
        'almacen' => '📦',
        'estadisticas' => '📊'
    ];
    ?>

    <div class="container">
        <div class="header">
            <h1>👤 Perfil de Usuario</h1>
            <p>Gestiona tu información personal y permisos</p>
        </div>

        <div class="content">
            <?php if ($message): ?>
                <div class="alert alert-<?php echo $messageType; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <?php if ($usuario): ?>
                <div class="profile-section">
                    <div class="profile-card">
                        <?php if ($usuario['imagen'] && file_exists('uploads/users/' . $usuario['imagen'])): ?>
                            <img src="uploads/users/<?php echo $usuario['imagen']; ?>" alt="Foto de perfil" class="profile-image">
                        <?php else: ?>
                            <div class="profile-image" style="background: rgba(255,255,255,0.2); display: flex; align-items: center; justify-content: center; font-size: 40px;">
                                👤
                            </div>
                        <?php endif; ?>
                        
                        <div class="profile-name"><?php echo htmlspecialchars($usuario['nombre']); ?></div>
                        <div class="profile-role"><?php echo htmlspecialchars($usuario['cargo'] ?? 'Usuario'); ?></div>
                        
                        <div class="profile-stats">
                            <div class="stat-item">
                                <div class="stat-number"><?php echo $stats_ventas; ?></div>
                                <div class="stat-label">Ventas</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-number"><?php echo $stats_ingresos; ?></div>
                                <div class="stat-label">Compras</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-number"><?php echo count($permisos_usuario); ?></div>
                                <div class="stat-label">Permisos</div>
                            </div>
                        </div>
                    </div>

                    <div class="profile-info">
                        <div class="info-title">📋 Información Personal</div>
                        
                        <div class="info-row">
                            <div class="info-label">Nombre:</div>
                            <div class="info-value"><?php echo htmlspecialchars($usuario['nombre']); ?></div>
                        </div>
                        
                        <div class="info-row">
                            <div class="info-label">Email:</div>
                            <div class="info-value"><?php echo htmlspecialchars($usuario['email']); ?></div>
                        </div>
                        
                        <div class="info-row">
                            <div class="info-label">Teléfono:</div>
                            <div class="info-value"><?php echo htmlspecialchars($usuario['telefono'] ?? 'No especificado'); ?></div>
                        </div>
                        
                        <div class="info-row">
                            <div class="info-label">Dirección:</div>
                            <div class="info-value"><?php echo htmlspecialchars($usuario['direccion'] ?? 'No especificada'); ?></div>
                        </div>
                        
                        <div class="info-row">
                            <div class="info-label">Documento:</div>
                            <div class="info-value"><?php echo htmlspecialchars($usuario['tipo_documento'] . ': ' . $usuario['num_documento']); ?></div>
                        </div>
                        
                        <div class="info-row">
                            <div class="info-label">Usuario:</div>
                            <div class="info-value"><?php echo htmlspecialchars($usuario['login']); ?></div>
                        </div>
                        
                        <button type="button" class="btn" onclick="toggleEditForm()">✏️ Editar Perfil</button>
                    </div>
                </div>

                <!-- Formulario de edición -->
                <div class="edit-form" id="editForm">
                    <div class="info-title">✏️ Editar Perfil</div>
                    
                    <form method="POST" action="">
                        <div class="form-group">
                            <label class="form-label">Nombre Completo</label>
                            <input type="text" name="nombre" class="form-control" value="<?php echo htmlspecialchars($usuario['nombre']); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($usuario['email']); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Teléfono</label>
                            <input type="text" name="telefono" class="form-control" value="<?php echo htmlspecialchars($usuario['telefono'] ?? ''); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Dirección</label>
                            <textarea name="direccion" class="form-control" rows="3"><?php echo htmlspecialchars($usuario['direccion'] ?? ''); ?></textarea>
                        </div>
                        
                        <button type="submit" name="update_profile" class="btn">💾 Guardar Cambios</button>
                        <button type="button" class="btn btn-secondary" onclick="toggleEditForm()">❌ Cancelar</button>
                    </form>
                </div>

                <!-- Sección de permisos -->
                <div class="permissions-section">
                    <div class="permissions-title">🔐 Permisos del Usuario</div>
                    
                    <div class="permissions-grid">
                        <?php foreach ($todos_permisos as $permiso): ?>
                            <div class="permission-card <?php echo in_array($permiso['nombre'], $permisos_activos) ? 'active' : ''; ?>">
                                <div class="permission-icon">
                                    <?php echo $iconos_permisos[$permiso['nombre']] ?? '🔒'; ?>
                                </div>
                                <div class="permission-name"><?php echo htmlspecialchars($permiso['nombre']); ?></div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

            <?php else: ?>
                <div class="alert alert-error">
                    Error al cargar la información del usuario.
                </div>
            <?php endif; ?>

            <div style="text-align: center; margin-top: 40px;">
                <a href="dashboard.php" class="btn btn-secondary">🏠 Volver al Dashboard</a>
                <a href="logout.php" class="btn" style="background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);">🚪 Cerrar Sesión</a>
            </div>
        </div>
    </div>

    <script src="./perfil_usuario.js"></script>
</body>
</html>