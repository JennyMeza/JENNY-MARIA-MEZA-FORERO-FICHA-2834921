// JavaScript para funcionalidades
let itemsFactura = [];

function cerrarModalVer() {
  document.getElementById("modalVerFactura").classList.remove("active");
}

function generarNumeroComprobante() {
  const numero = Math.floor(Math.random() * 9000) + 1000;
  document.getElementById("numero").value = numero.toString().padStart(3, "0");
}

function agregarArticulo() {
  const select = document.createElement("select");
  select.innerHTML = '<option value="">Seleccionar artículo...</option>';

  articulos.forEach((articulo) => {
    const option = document.createElement("option");
    option.value = articulo.idarticulo;
    option.textContent = `${articulo.nombre} - Stock: ${articulo.stock}`;
    option.dataset.precio = 100;
    select.appendChild(option);
  });

  const row = document.createElement("tr");
  row.innerHTML = `
                <td>
                    ${select.outerHTML}
                </td>
                <td><input type="number" min="1" value="1" onchange="calcularSubtotal(this)"></td>
                <td><input type="number" step="0.01" min="0" value="100.00" onchange="calcularSubtotal(this)"></td>
                <td><input type="number" step="0.01" min="0" value="0.00" onchange="calcularSubtotal(this)"></td>
                <td class="subtotal">$100.00</td>
                <td><button type="button" onclick="eliminarArticulo(this)" style="background: #f56565; color: white; border: none; padding: 5px 10px; border-radius: 4px;">❌</button></td>
            `;

  document.getElementById("itemsTable").appendChild(row);
  calcularTotales();
}

function eliminarArticulo(btn) {
  btn.closest("tr").remove();
  calcularTotales();
}

function calcularSubtotal(input) {
  const row = input.closest("tr");
  const cantidad =
    parseFloat(row.querySelector('input[type="number"]').value) || 0;
  const precio =
    parseFloat(row.querySelectorAll('input[type="number"]')[1].value) || 0;
  const descuento =
    parseFloat(row.querySelectorAll('input[type="number"]')[2].value) || 0;

  const subtotal = cantidad * precio - descuento;
  row.querySelector(".subtotal").textContent = "$" + subtotal.toFixed(2);

  calcularTotales();
}

function calcularTotales() {
  const rows = document.querySelectorAll("#itemsTable tr");
  let subtotal = 0;
  let totalDescuento = 0;

  rows.forEach((row) => {
    const cantidad =
      parseFloat(row.querySelector('input[type="number"]').value) || 0;
    const precio =
      parseFloat(row.querySelectorAll('input[type="number"]')[1].value) || 0;
    const descuento =
      parseFloat(row.querySelectorAll('input[type="number"]')[2].value) || 0;

    subtotal += cantidad * precio;
    totalDescuento += descuento;
  });

  const impuestoPorcentaje =
    parseFloat(document.getElementById("impuesto").value) || 0;
  const subtotalConDescuento = subtotal - totalDescuento;
  const impuesto = subtotalConDescuento * (impuestoPorcentaje / 100);
  const total = subtotalConDescuento + impuesto;

  document.getElementById("subtotal").textContent = "$" + subtotal.toFixed(2);
  document.getElementById("totalDescuento").textContent =
    "$" + totalDescuento.toFixed(2);
  document.getElementById("totalImpuesto").textContent =
    "$" + impuesto.toFixed(2);
  document.getElementById("totalFinal").textContent = "$" + total.toFixed(2);
}

function guardarFactura() {
  const rows = document.querySelectorAll("#itemsTable tr");
  const articulos = [];

  rows.forEach((row) => {
    const select = row.querySelector("select");
    const cantidad = row.querySelector('input[type="number"]').value;
    const precio = row.querySelectorAll('input[type="number"]')[1].value;
    const descuento = row.querySelectorAll('input[type="number"]')[2].value;

    if (select.value) {
      articulos.push({
        idarticulo: select.value,
        cantidad: parseInt(cantidad),
        precio_venta: parseFloat(precio),
        descuento: parseFloat(descuento),
      });
    }
  });

  if (articulos.length === 0) {
    alert("Debe agregar al menos un artículo");
    return;
  }

  if (!document.getElementById("cliente").value) {
    alert("Debe seleccionar un cliente");
    return;
  }

  document.getElementById("articulosInput").value = JSON.stringify(articulos);

  const total = document
    .getElementById("totalFinal")
    .textContent.replace("$", "");
  const totalInput = document.createElement("input");
  totalInput.type = "hidden";
  totalInput.name = "total";
  totalInput.value = total;
  document.getElementById("formFactura").appendChild(totalInput);

  document.getElementById("formFactura").submit();
}

function verFactura(idventa) {
  fetch(`?action=ver_detalles&id=${idventa}`)
    .then((response) => response.json())
    .then((detalles) => {
      let contenido = `
                        <div class="factura-detalles">
                            <h3>Detalles de la Factura #${String(
                              idventa
                            ).padStart(3, "0")}</h3>
                            <table class="detalles-table">
                                <thead>
                                    <tr>
                                        <th>Código</th>
                                        <th>Artículo</th>
                                        <th>Cantidad</th>
                                        <th>Precio</th>
                                        <th>Descuento</th>
                                        <th>Subtotal</th>
                                    </tr>
                                </thead>
                                <tbody>
                    `;

      let total = 0;
      detalles.forEach((detalle) => {
        const subtotal =
          detalle.cantidad * detalle.precio_venta - (detalle.descuento || 0);
        total += subtotal;
        contenido += `
                            <tr>
                                <td>${detalle.codigo || "N/A"}</td>
                                <td>${detalle.articulo_nombre}</td>
                                <td>${detalle.cantidad}</td>
                                <td>$${parseFloat(detalle.precio_venta).toFixed(
                                  2
                                )}</td>
                                <td>$${parseFloat(
                                  detalle.descuento || 0
                                ).toFixed(2)}</td>
                                <td>$${subtotal.toFixed(2)}</td>
                            </tr>
                        `;
      });

      contenido += `
                                </tbody>
                            </table>
                            <div class="total-factura">
                                <strong>Total: $${total.toFixed(2)}</strong>
                            </div>
                        </div>
                    `;

      document.getElementById("contenidoFactura").innerHTML = contenido;
      document.getElementById("modalVerFactura").style.display = "block";
    })
    .catch((error) => {
      console.error("Error:", error);
      alert("Error al cargar los detalles de la factura");
    });
}

function imprimirFactura(idventa) {
  const ventanaImpresion = window.open("", "_blank", "width=800,height=600");

  fetch(`?action=ver_detalles&id=${idventa}`)
    .then((response) => response.json())
    .then((detalles) => {
      let contenidoImpresion = `
                        <!DOCTYPE html>
                        <html>
                        <head>
                            <title>Factura #${String(idventa).padStart(
                              3,
                              "0"
                            )}</title>
                            <style>
                                body { font-family: Arial, sans-serif; margin: 20px; }
                                .header { text-align: center; margin-bottom: 30px; }
                                .factura-info { margin-bottom: 20px; }
                                table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
                                th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                                th { background-color: #f2f2f2; }
                                .total { text-align: right; font-weight: bold; font-size: 18px; }
                                @media print { .no-print { display: none; } }
                            </style>
                        </head>
                        <body>
                            <div class="header">
                                <h1>NeoPOS</h1>
                                <h2>Factura #${String(idventa).padStart(
                                  3,
                                  "0"
                                )}</h2>
                                <p>Fecha: ${new Date().toLocaleDateString()}</p>
                            </div>
                            
                            <table>
                                <thead>
                                    <tr>
                                        <th>Código</th>
                                        <th>Artículo</th>
                                        <th>Cantidad</th>
                                        <th>Precio</th>
                                        <th>Descuento</th>
                                        <th>Subtotal</th>
                                    </tr>
                                </thead>
                                <tbody>
                    `;

      let total = 0;
      detalles.forEach((detalle) => {
        const subtotal =
          detalle.cantidad * detalle.precio_venta - (detalle.descuento || 0);
        total += subtotal;
        contenidoImpresion += `
                            <tr>
                                <td>${detalle.codigo || "N/A"}</td>
                                <td>${detalle.articulo_nombre}</td>
                                <td>${detalle.cantidad}</td>
                                <td>$${parseFloat(detalle.precio_venta).toFixed(
                                  2
                                )}</td>
                                <td>$${parseFloat(
                                  detalle.descuento || 0
                                ).toFixed(2)}</td>
                                <td>$${subtotal.toFixed(2)}</td>
                            </tr>
                        `;
      });

      contenidoImpresion += `
                                </tbody>
                            </table>
                            
                            <div class="total">
                                Total: $${total.toFixed(2)}
                            </div>
                            
                            <div class="no-print" style="text-align: center; margin-top: 30px;">
                                <button onclick="window.print()">Imprimir</button>
                                <button onclick="window.close()">Cerrar</button>
                            </div>
                        </body>
                        </html>
                    `;

      ventanaImpresion.document.write(contenidoImpresion);
      ventanaImpresion.document.close();
    })
    .catch((error) => {
      console.error("Error:", error);
      alert("Error al generar la factura para impresión");
      ventanaImpresion.close();
    });
}

function anularFactura(idventa) {
  if (
    confirm(
      "¿Está seguro de que desea anular esta factura? Esta acción no se puede deshacer."
    )
  ) {
    const form = document.createElement("form");
    form.method = "POST";
    form.innerHTML = `
                    <input type="hidden" name="anular_factura" value="1">
                    <input type="hidden" name="idventa" value="${idventa}">
                `;
    document.body.appendChild(form);
    form.submit();
  }
}

window.onclick = function (event) {
  const modalFactura = document.getElementById("modalFactura");
  const modalVerFactura = document.getElementById("modalVerFactura");

  if (event.target == modalFactura) {
    cerrarModal();
  }
  if (event.target == modalVerFactura) {
    cerrarModalVer();
  }
};

document.addEventListener("change", function (e) {
  if (e.target.tagName === "SELECT" && e.target.closest("#itemsTable")) {
    const selectedOption = e.target.options[e.target.selectedIndex];
    const precio = selectedOption.dataset.precio || 100;
    const row = e.target.closest("tr");
    const precioInput = row.querySelectorAll('input[type="number"]')[1];
    precioInput.value = precio;
    calcularSubtotal(precioInput);
  }
});

document.getElementById("impuesto").addEventListener("input", function () {
  calcularTotales();
});

document
  .getElementById("tipo_comprobante")
  .addEventListener("change", function () {
    const tipo = this.value;
    const serie = document.getElementById("serie");

    switch (tipo) {
      case "Boleta":
        serie.value = "B001";
        break;
      case "Factura":
        serie.value = "F001";
        break;
      case "Ticket":
        serie.value = "T001";
        break;
      default:
        serie.value = "B001";
    }
  });

document.addEventListener("DOMContentLoaded", function () {});

let modoEdicion = false;
let facturaEditando = null;

function editarFactura(idventa) {
  fetch(`?action=obtener_factura&id=${idventa}`)
    .then((response) => response.json())
    .then((data) => {
      if (!data || !data.venta) {
        alert("Error al cargar los datos de la factura");
        return;
      }

      modoEdicion = true;
      facturaEditando = idventa;

      llenarFormularioParaEditar(data);

      document.querySelector("#modalFactura .modal-header h2").textContent =
        "✏️ Editar Factura #" + String(idventa).padStart(3, "0");

      document.querySelector("#modalFactura .btn-primary").textContent =
        "💾 Actualizar Factura";

      document.getElementById("modalFactura").classList.add("active"); // CAMBIO AQUI
    })
    .catch((error) => {
      console.error("Error:", error);
      alert("Error al cargar los datos de la factura");
    });
}

function llenarFormularioParaEditar(data) {
  const venta = data.venta;
  const detalles = data.detalles;

  document.getElementById("cliente").value = venta.idcliente || "";
  document.getElementById("tipo_comprobante").value = venta.tipo_comprobante;
  document.getElementById("serie").value = venta.serie_comprobante;
  document.getElementById("numero").value = venta.num_comprobante;
  document.getElementById("fecha").value = venta.fecha_hora.replace(" ", "T");
  document.getElementById("estado").value = venta.estado;
  document.getElementById("impuesto").value = venta.impuesto;

  document.getElementById("itemsTable").innerHTML = "";
  itemsFactura = [];

  detalles.forEach((detalle) => {
    agregarArticuloExistente(detalle);
  });

  calcularTotales();
}

function agregarArticuloExistente(detalle) {
  const select = document.createElement("select");
  select.innerHTML = '<option value="">Seleccionar artículo...</option>';

  articulos.forEach((articulo) => {
    const option = document.createElement("option");
    option.value = articulo.idarticulo;
    option.textContent = `${articulo.nombre} - Stock: ${articulo.stock}`;
    option.dataset.precio = detalle.precio_venta;
    if (articulo.idarticulo == detalle.idarticulo) {
      option.selected = true;
    }
    select.appendChild(option);
  });

  const row = document.createElement("tr");
  row.innerHTML = `
        <td>
            ${select.outerHTML}
        </td>
        <td><input type="number" min="1" value="${
          detalle.cantidad
        }" onchange="calcularSubtotal(this)"></td>
        <td><input type="number" step="0.01" min="0" value="${parseFloat(
          detalle.precio_venta
        ).toFixed(2)}" onchange="calcularSubtotal(this)"></td>
        <td><input type="number" step="0.01" min="0" value="${parseFloat(
          detalle.descuento || 0
        ).toFixed(2)}" onchange="calcularSubtotal(this)"></td>
        <td class="subtotal">$${(
          detalle.cantidad * detalle.precio_venta -
          (detalle.descuento || 0)
        ).toFixed(2)}</td>
        <td><button type="button" onclick="eliminarArticulo(this)" style="background: #f56565; color: white; border: none; padding: 5px 10px; border-radius: 4px;">❌</button></td>
    `;

  document.getElementById("itemsTable").appendChild(row);
}

function guardarFactura() {
  const rows = document.querySelectorAll("#itemsTable tr");
  const articulos = [];

  rows.forEach((row) => {
    const select = row.querySelector("select");
    const cantidad = row.querySelector('input[type="number"]').value;
    const precio = row.querySelectorAll('input[type="number"]')[1].value;
    const descuento = row.querySelectorAll('input[type="number"]')[2].value;

    if (select.value) {
      articulos.push({
        idarticulo: select.value,
        cantidad: parseInt(cantidad),
        precio_venta: parseFloat(precio),
        descuento: parseFloat(descuento),
      });
    }
  });

  if (articulos.length === 0) {
    alert("Debe agregar al menos un artículo");
    return;
  }

  if (!document.getElementById("cliente").value) {
    alert("Debe seleccionar un cliente");
    return;
  }

  document.getElementById("articulosInput").value = JSON.stringify(articulos);

  const total = document
    .getElementById("totalFinal")
    .textContent.replace("$", "");
  let totalInput = document.querySelector('input[name="total"]');
  if (!totalInput) {
    totalInput = document.createElement("input");
    totalInput.type = "hidden";
    totalInput.name = "total";
    document.getElementById("formFactura").appendChild(totalInput);
  }
  totalInput.value = total;

  if (modoEdicion) {
    let editarInput = document.querySelector('input[name="editar_factura"]');
    if (!editarInput) {
      editarInput = document.createElement("input");
      editarInput.type = "hidden";
      editarInput.name = "editar_factura";
      document.getElementById("formFactura").appendChild(editarInput);
    }
    editarInput.value = "1";

    let idventaInput = document.querySelector('input[name="idventa"]');
    if (!idventaInput) {
      idventaInput = document.createElement("input");
      idventaInput.type = "hidden";
      idventaInput.name = "idventa";
      document.getElementById("formFactura").appendChild(idventaInput);
    }
    idventaInput.value = facturaEditando;
  }

  document.getElementById("formFactura").submit();
}

function cerrarModal() {
  document.getElementById("modalFactura").classList.remove("active"); // CAMBIO AQUI
  document.getElementById("formFactura").reset();
  itemsFactura = [];
  document.getElementById("itemsTable").innerHTML = "";
  calcularTotales();

  modoEdicion = false;
  facturaEditando = null;

  document.querySelector("#modalFactura .modal-header h2").textContent =
    "📄 Nueva Factura";
  document.querySelector("#modalFactura .btn-primary").textContent =
    "💾 Guardar Factura";

  const editarInput = document.querySelector('input[name="editar_factura"]');
  const idventaInput = document.querySelector('input[name="idventa"]');
  if (editarInput) editarInput.remove();
  if (idventaInput) idventaInput.remove();
}

function abrirModalFactura() {
  modoEdicion = false;
  facturaEditando = null;

  const modalElement = document.querySelector(".modal");

  if (modalElement) {
    modalElement.classList.add("active");
  } else {
    console.warn("No se encontró ningún elemento con la clase 'modal'.");
  }

  generarNumeroComprobante();

  document.querySelector("#modalFactura .modal-header h2").textContent =
    "📄 Nueva Factura";
  document.querySelector("#modalFactura .btn-primary").textContent =
    "💾 Guardar Factura";
}
