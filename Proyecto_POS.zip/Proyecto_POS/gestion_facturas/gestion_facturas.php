<?php
require_once '../config.php';

// Verificar sesión (comentado como en tu ejemplo)
// if (!isset($_SESSION['user_id'])) {
//     header('Location: login.php');
//     exit();
// }

$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['crear_factura'])) {
    try {
        $pdo = getConnection();
        $pdo->beginTransaction();
        

        $idcliente = null;
        
        if (!empty($_POST['cliente'])) {
            if ($_POST['cliente'] === 'nuevo') {
              
                $idcliente = null; 
            } else {
                // Verificar que el cliente existe
                $stmt = $pdo->prepare("SELECT idpersona FROM persona WHERE idpersona = ? AND tipo_persona = 'cliente'");
                $stmt->execute([$_POST['cliente']]);
                $cliente_existe = $stmt->fetchColumn();
                
                if ($cliente_existe) {
                    $idcliente = $_POST['cliente'];
                } else {
                    throw new Exception("El cliente seleccionado no existe");
                }
            }
        }
        
        // Si no hay cliente válido, crear un cliente genérico o usar null
        if ($idcliente === null) {
            // Opción 1: Crear cliente genérico
            $stmt = $pdo->prepare("INSERT INTO persona (tipo_persona, nombre, tipo_documento, num_documento, direccion, telefono, email) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                'cliente',
                'Cliente Genérico',
                'DNI',
                '00000000',
                'Sin dirección',
                '000000000',
                'sin@email.com'
            ]);
            $idcliente = $pdo->lastInsertId();
            
          
        }
        
        // Insertar la venta principal
        $stmt = $pdo->prepare("INSERT INTO venta (idcliente, idusuario, tipo_comprobante, serie_comprobante, num_comprobante, fecha_hora, impuesto, total_venta, estado) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        
        $stmt->execute([
            $idcliente,
            1, // Usuario actual - deberías obtener esto de la sesión
            $_POST['tipo_comprobante'],
            $_POST['serie'],
            $_POST['numero'],
            $_POST['fecha'],
            $_POST['impuesto'],
            $_POST['total'],
            $_POST['estado']
        ]);
        
        $idventa = $pdo->lastInsertId();
        
        // Insertar detalles de la venta
        if (isset($_POST['articulos']) && !empty($_POST['articulos'])) {
            $articulos = json_decode($_POST['articulos'], true);
            
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new Exception("Error en el formato de artículos");
            }
            
            foreach ($articulos as $articulo) {
                // Validar que el artículo existe
                $stmt = $pdo->prepare("SELECT idarticulo, stock FROM articulo WHERE idarticulo = ?");
                $stmt->execute([$articulo['idarticulo']]);
                $articulo_data = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$articulo_data) {
                    throw new Exception("El artículo con ID {$articulo['idarticulo']} no existe");
                }
                
                // Verificar stock suficiente
                if ($articulo_data['stock'] < $articulo['cantidad']) {
                    throw new Exception("Stock insuficiente para el artículo ID {$articulo['idarticulo']}");
                }
                
                // Insertar detalle de venta
                $stmt = $pdo->prepare("INSERT INTO detalle_venta (idventa, idarticulo, cantidad, precio_venta, descuento) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([
                    $idventa,
                    $articulo['idarticulo'],
                    $articulo['cantidad'],
                    $articulo['precio_venta'],
                    $articulo['descuento'] ?? 0
                ]);
                
                // Actualizar stock del artículo
                $stmt = $pdo->prepare("UPDATE articulo SET stock = stock - ? WHERE idarticulo = ?");
                $stmt->execute([$articulo['cantidad'], $articulo['idarticulo']]);
            }
        }
        
        $pdo->commit();
        $message = "Factura creada exitosamente con ID: " . $idventa;
        $messageType = 'success';
        
    } catch (Exception $e) {
        $pdo->rollBack();
        $message = "Error al crear la factura: " . $e->getMessage();
        $messageType = 'error';
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['editar_factura'])) {
    try {
        $pdo = getConnection();
        $pdo->beginTransaction();
        
        $idventa = $_POST['idventa'];
        
        // Validar que la factura existe y no está anulada
        $stmt = $pdo->prepare("SELECT estado FROM venta WHERE idventa = ?");
        $stmt->execute([$idventa]);
        $factura_actual = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$factura_actual) {
            throw new Exception("La factura no existe");
        }
        
        if ($factura_actual['estado'] === 'Anulada') {
            throw new Exception("No se puede editar una factura anulada");
        }
        
        // Validar y obtener el cliente
        $idcliente = null;
        if (!empty($_POST['cliente']) && $_POST['cliente'] !== 'nuevo') {
            $stmt = $pdo->prepare("SELECT idpersona FROM persona WHERE idpersona = ? AND tipo_persona = 'cliente'");
            $stmt->execute([$_POST['cliente']]);
            $cliente_existe = $stmt->fetchColumn();
            
            if ($cliente_existe) {
                $idcliente = $_POST['cliente'];
            } else {
                throw new Exception("El cliente seleccionado no existe");
            }
        }
        
        // Restaurar stock de los artículos anteriores
        $stmt = $pdo->prepare("SELECT idarticulo, cantidad FROM detalle_venta WHERE idventa = ?");
        $stmt->execute([$idventa]);
        $detalles_anteriores = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($detalles_anteriores as $detalle) {
            $stmt = $pdo->prepare("UPDATE articulo SET stock = stock + ? WHERE idarticulo = ?");
            $stmt->execute([$detalle['cantidad'], $detalle['idarticulo']]);
        }
        
        // Eliminar detalles anteriores
        $stmt = $pdo->prepare("DELETE FROM detalle_venta WHERE idventa = ?");
        $stmt->execute([$idventa]);
        
        // Actualizar la venta principal
        $stmt = $pdo->prepare("UPDATE venta SET idcliente = ?, tipo_comprobante = ?, serie_comprobante = ?, num_comprobante = ?, fecha_hora = ?, impuesto = ?, total_venta = ?, estado = ? WHERE idventa = ?");
        
        $stmt->execute([
            $idcliente,
            $_POST['tipo_comprobante'],
            $_POST['serie'],
            $_POST['numero'],
            $_POST['fecha'],
            $_POST['impuesto'],
            $_POST['total'],
            $_POST['estado'],
            $idventa
        ]);
        
        // Insertar nuevos detalles de la venta
        if (isset($_POST['articulos']) && !empty($_POST['articulos'])) {
            $articulos = json_decode($_POST['articulos'], true);
            
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new Exception("Error en el formato de artículos");
            }
            
            foreach ($articulos as $articulo) {
                // Validar que el artículo existe
                $stmt = $pdo->prepare("SELECT idarticulo, stock FROM articulo WHERE idarticulo = ?");
                $stmt->execute([$articulo['idarticulo']]);
                $articulo_data = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$articulo_data) {
                    throw new Exception("El artículo con ID {$articulo['idarticulo']} no existe");
                }
                
                // Verificar stock suficiente
                if ($articulo_data['stock'] < $articulo['cantidad']) {
                    throw new Exception("Stock insuficiente para el artículo ID {$articulo['idarticulo']}");
                }
                
                // Insertar nuevo detalle de venta
                $stmt = $pdo->prepare("INSERT INTO detalle_venta (idventa, idarticulo, cantidad, precio_venta, descuento) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([
                    $idventa,
                    $articulo['idarticulo'],
                    $articulo['cantidad'],
                    $articulo['precio_venta'],
                    $articulo['descuento'] ?? 0
                ]);
                
                // Actualizar stock del artículo
                $stmt = $pdo->prepare("UPDATE articulo SET stock = stock - ? WHERE idarticulo = ?");
                $stmt->execute([$articulo['cantidad'], $articulo['idarticulo']]);
            }
        }
        
        $pdo->commit();
        $message = "Factura editada exitosamente";
        $messageType = 'success';
        
    } catch (Exception $e) {
        $pdo->rollBack();
        $message = "Error al editar la factura: " . $e->getMessage();
        $messageType = 'error';
    }
}

// Función para obtener datos completos de una factura para editar
function obtenerFacturaCompleta($idventa) {
    try {
        $pdo = getConnection();
        
        // Obtener datos de la venta
        $stmt = $pdo->prepare("
            SELECT v.*, p.nombre as cliente_nombre, p.idpersona as idcliente
            FROM venta v 
            LEFT JOIN persona p ON v.idcliente = p.idpersona 
            WHERE v.idventa = ?
        ");
        $stmt->execute([$idventa]);
        $venta = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$venta) {
            return null;
        }
        
        // Obtener detalles de la venta
        $stmt = $pdo->prepare("
            SELECT dv.*, a.nombre as articulo_nombre, a.codigo 
            FROM detalle_venta dv 
            LEFT JOIN articulo a ON dv.idarticulo = a.idarticulo 
            WHERE dv.idventa = ?
        ");
        $stmt->execute([$idventa]);
        $detalles = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        return [
            'venta' => $venta,
            'detalles' => $detalles
        ];
        
    } catch (Exception $e) {
        return null;
    }
}

// Si se solicita obtener datos para editar (AJAX)
if (isset($_GET['action']) && $_GET['action'] == 'obtener_factura' && isset($_GET['id'])) {
    $datos = obtenerFacturaCompleta($_GET['id']);
    header('Content-Type: application/json');
    echo json_encode($datos);
    exit;
}

// Procesar anulación de factura
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['anular_factura'])) {
    try {
        $pdo = getConnection();
        $stmt = $pdo->prepare("UPDATE venta SET estado = 'Anulada' WHERE idventa = ?");
        $stmt->execute([$_POST['idventa']]);
        
        $message = "Factura anulada exitosamente";
        $messageType = 'success';
    } catch (Exception $e) {
        $message = "Error al anular la factura";
        $messageType = 'error';
    }
}

// Obtener filtros
$fecha_desde = $_GET['fecha_desde'] ?? '';
$fecha_hasta = $_GET['fecha_hasta'] ?? '';
$cliente_filtro = $_GET['cliente'] ?? '';
$estado_filtro = $_GET['estado'] ?? '';

try {
    $pdo = getConnection();
    
    // Construir consulta con filtros
    $sql = "SELECT v.*, p.nombre as cliente_nombre, p.num_documento, u.nombre as usuario_nombre 
            FROM venta v 
            LEFT JOIN persona p ON v.idcliente = p.idpersona 
            LEFT JOIN usuario u ON v.idusuario = u.idusuario 
            WHERE 1=1";
    
    $params = [];
    
    if (!empty($fecha_desde)) {
        $sql .= " AND DATE(v.fecha_hora) >= ?";
        $params[] = $fecha_desde;
    }
    
    if (!empty($fecha_hasta)) {
        $sql .= " AND DATE(v.fecha_hora) <= ?";
        $params[] = $fecha_hasta;
    }
    
    if (!empty($cliente_filtro)) {
        $sql .= " AND p.nombre LIKE ?";
        $params[] = '%' . $cliente_filtro . '%';
    }
    
    if (!empty($estado_filtro)) {
        $sql .= " AND v.estado = ?";
        $params[] = $estado_filtro;
    }
    
    $sql .= " ORDER BY v.fecha_hora DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $facturas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Obtener estadísticas
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM venta WHERE estado != 'Anulada'");
    $total_facturas = $stmt->fetchColumn();
    
    $stmt = $pdo->query("SELECT SUM(total_venta) as total FROM venta WHERE estado != 'Anulada'");
    $monto_total = $stmt->fetchColumn() ?? 0;
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM venta WHERE estado = 'Pagada'");
    $facturas_pagadas = $stmt->fetchColumn();
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM venta WHERE estado = 'Pendiente'");
    $facturas_pendientes = $stmt->fetchColumn();
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM venta WHERE estado = 'Vencida'");
    $facturas_vencidas = $stmt->fetchColumn();
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM venta WHERE DATE(fecha_hora) = CURDATE()");
    $facturas_hoy = $stmt->fetchColumn();
    
    // Obtener clientes para el filtro
    $stmt = $pdo->query("SELECT * FROM persona WHERE tipo_persona = 'cliente' ORDER BY nombre");
    $clientes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Obtener artículos para la factura
    $stmt = $pdo->query("SELECT a.*, c.nombre as categoria_nombre FROM articulo a LEFT JOIN categoria c ON a.idcategoria = c.idcategoria WHERE a.condicion = 1 ORDER BY a.nombre");
    $articulos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    $facturas = [];
    $clientes = [];
    $articulos = [];
    $total_facturas = 0;
    $monto_total = 0;
    $facturas_pagadas = 0;
    $facturas_pendientes = 0;
    $facturas_vencidas = 0;
    $facturas_hoy = 0;
}

// Función para obtener detalles de una factura
function obtenerDetallesFactura($idventa) {
    try {
        $pdo = getConnection();
        $stmt = $pdo->prepare("
            SELECT dv.*, a.nombre as articulo_nombre, a.codigo 
            FROM detalle_venta dv 
            LEFT JOIN articulo a ON dv.idarticulo = a.idarticulo 
            WHERE dv.idventa = ?
        ");
        $stmt->execute([$idventa]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        return [];
    }
}

// Si se solicita ver detalles de factura (AJAX)
if (isset($_GET['action']) && $_GET['action'] == 'ver_detalles' && isset($_GET['id'])) {
    $detalles = obtenerDetallesFactura($_GET['id']);
    header('Content-Type: application/json');
    echo json_encode($detalles);
    exit;
}

// Si se solicita exportar facturas
if (isset($_GET['action']) && $_GET['action'] == 'exportar') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="facturas_' . date('Y-m-d') . '.csv"');
    
    $output = fopen('php://output', 'w');
    fputcsv($output, ['Factura', 'Fecha', 'Cliente', 'Documento', 'Comprobante', 'Total', 'Estado', 'Usuario']);
    
    foreach ($facturas as $factura) {
        fputcsv($output, [
            '#' . str_pad($factura['idventa'], 3, '0', STR_PAD_LEFT),
            date('d/m/Y H:i', strtotime($factura['fecha_hora'])),
            $factura['cliente_nombre'],
            $factura['num_documento'],
            $factura['tipo_comprobante'] . ' ' . $factura['serie_comprobante'] . '-' . $factura['num_comprobante'],
            '$' . number_format($factura['total_venta'], 2),
            $factura['estado'],
            $factura['usuario_nombre']
        ]);
    }
    
    fclose($output);
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Facturas - NeoPOS</title>
    <link rel="stylesheet" href="./gestion_facturas.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="header-left">
                <h1>📄 Gestión de Facturas</h1>
                <p>Administra todas las facturas de venta</p>
            </div>
            <div class="header-actions">
                <button onclick="abrirModalFactura()" class="btn btn-primary">
                    ➕ Nueva Factura
                </button>
                <a href="?action=exportar<?php echo !empty($_SERVER['QUERY_STRING']) ? '&' . $_SERVER['QUERY_STRING'] : ''; ?>" class="btn btn-secondary">
                    📊 Exportar
                </a>
            </div>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-<?php echo $messageType; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <!-- Estadísticas -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">📊</div>
                <div class="stat-number"><?php echo $total_facturas; ?></div>
                <div class="stat-label">Total Facturas</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">💰</div>
                <div class="stat-number">$<?php echo number_format($monto_total, 2); ?></div>
                <div class="stat-label">Monto Total</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">✅</div>
                <div class="stat-number"><?php echo $facturas_pagadas; ?></div>
                <div class="stat-label">Pagadas</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">⏳</div>
                <div class="stat-number"><?php echo $facturas_pendientes; ?></div>
                <div class="stat-label">Pendientes</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">⚠️</div>
                <div class="stat-number"><?php echo $facturas_vencidas; ?></div>
                <div class="stat-label">Vencidas</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">📅</div>
                <div class="stat-number"><?php echo $facturas_hoy; ?></div>
                <div class="stat-label">Hoy</div>
            </div>
        </div>

        <!-- Filtros -->
        <div class="filters">
            <form method="GET" action="">
                <div class="filters-row">
                    <div class="filter-group">
                        <label class="filter-label">Fecha Desde</label>
                        <input type="date" name="fecha_desde" class="filter-control" value="<?php echo htmlspecialchars($fecha_desde); ?>">
                    </div>
                    <div class="filter-group">
                        <label class="filter-label">Fecha Hasta</label>
                        <input type="date" name="fecha_hasta" class="filter-control" value="<?php echo htmlspecialchars($fecha_hasta); ?>">
                    </div>
                    <div class="filter-group">
                        <label class="filter-label">Cliente</label>
                        <select name="cliente" class="filter-control">
                            <option value="">Todos los clientes</option>
                            <?php foreach ($clientes as $cliente): ?>
                                <option value="<?php echo htmlspecialchars($cliente['nombre']); ?>" 
                                        <?php echo $cliente_filtro == $cliente['nombre'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($cliente['nombre']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label class="filter-label">Estado</label>
                        <select name="estado" class="filter-control">
                            <option value="">Todos los estados</option>
                            <option value="Pagada" <?php echo $estado_filtro == 'Pagada' ? 'selected' : ''; ?>>Pagada</option>
                            <option value="Pendiente" <?php echo $estado_filtro == 'Pendiente' ? 'selected' : ''; ?>>Pendiente</option>
                            <option value="Vencida" <?php echo $estado_filtro == 'Vencida' ? 'selected' : ''; ?>>Vencida</option>
                            <option value="Anulada" <?php echo $estado_filtro == 'Anulada' ? 'selected' : ''; ?>>Anulada</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <button type="submit" class="btn btn-primary">🔍 Filtrar</button>
                    </div>
                </div>
            </form>
        </div>

        <div class="content">
            <table class="invoices-table">
                <thead>
                    <tr>
                        <th>Factura</th>
                        <th>Fecha</th>
                        <th>Cliente</th>
                        <th>Comprobante</th>
                        <th>Total</th>
                        <th>Estado</th>
                        <th>Usuario</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($facturas as $factura): ?>
                    <tr>
                        <td><strong>#<?php echo str_pad($factura['idventa'], 3, '0', STR_PAD_LEFT); ?></strong></td>
                        <td><?php echo date('d/m/Y H:i', strtotime($factura['fecha_hora'])); ?></td>
                        <td>
                            <?php echo htmlspecialchars($factura['cliente_nombre'] ?? 'Sin cliente'); ?><br>
                            <small><?php echo htmlspecialchars($factura['num_documento'] ?? ''); ?></small>
                        </td>
                        <td>
                            <?php echo htmlspecialchars($factura['tipo_comprobante']); ?><br>
                            <small><?php echo htmlspecialchars($factura['serie_comprobante'] . '-' . $factura['num_comprobante']); ?></small>
                        </td>
                        <td><strong>$<?php echo number_format($factura['total_venta'], 2); ?></strong></td>
                        <td>
                            <span class="status-badge status-<?php echo strtolower($factura['estado']); ?>">
                                <?php echo htmlspecialchars($factura['estado']); ?>
                            </span>
                        </td>
                        <td><?php echo htmlspecialchars($factura['usuario_nombre'] ?? 'admin'); ?></td>
                        <td>
    <a href="#" class="btn-action" onclick="verFactura(<?php echo $factura['idventa']; ?>)">
        👁️ Ver
    </a>
    <?php if ($factura['estado'] != 'Anulada'): ?>
    <a href="#" class="btn-action" style="background: #38a169;" onclick="editarFactura(<?php echo $factura['idventa']; ?>)">
        ✏️ Editar
    </a>
    <?php endif; ?>
    <a href="#" class="btn-action btn-print" onclick="imprimirFactura(<?php echo $factura['idventa']; ?>)">
        🖨️ Imprimir
    </a>
    <?php if ($factura['estado'] != 'Anulada'): ?>
    <a href="#" class="btn-action" style="background: #f56565;" onclick="anularFactura(<?php echo $factura['idventa']; ?>)">
        ❌ Anular
    </a>
    <?php endif; ?>
</td>
                    </tr>
                    <?php endforeach; ?>
                    
                    <?php if (empty($facturas)): ?>
                    <tr>
                        <td colspan="8" style="text-align: center; padding: 40px;">
                            <div style="color: #888;">
                                📄 No se encontraron facturas
                            </div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Modal Nueva Factura -->
    <div id="modalFactura" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>📄 Nueva Factura</h2>
                <span class="close" onclick="cerrarModal()">&times;</span>
            </div>
            
            <div class="modal-body">
                <form id="formFactura" method="POST" action="">
                    <input type="hidden" name="crear_factura" value="1">
                    <input type="hidden" name="articulos" id="articulosInput">
                    
                    <!-- Información del Cliente -->
                    <div class="form-section">
                        <h3>👤 Información del Cliente</h3>
                        <div class="form-row">
                            <div class="form-group">
                                <label>Cliente *</label>
                                <select id="cliente" name="cliente" required>
                                    <option value="">Seleccionar cliente...</option>
                                    <?php foreach ($clientes as $cliente): ?>
                                        <option value="<?php echo $cliente['idpersona']; ?>">
                                            <?php echo htmlspecialchars($cliente['nombre'] . ' - ' . $cliente['num_documento']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                    <option value="nuevo">+ Cliente Nuevo</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Tipo de Documento</label>
                                <select id="tipo_documento" name="tipo_documento">
                                    <option value="DNI">DNI</option>
                                    <option value="RUC">RUC</option>
                                    <option value="CEDULA">CÉDULA</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <!-- Información de la Factura -->
                    <div class="form-section">
                        <h3>📋 Información de la Factura</h3>
                        <div class="form-row">
                            <div class="form-group">
                                <label>Tipo de Comprobante *</label>
                                <select id="tipo_comprobante" name="tipo_comprobante" required>
                                    <option value="Boleta">Boleta</option>
                                    <option value="Factura">Factura</option>
                                    <option value="Ticket">Ticket</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Serie</label>
                                <input type="text" id="serie" name="serie" value="B001" placeholder="Serie del comprobante">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>Número</label>
                                <input type="text" id="numero" name="numero" placeholder="Número del comprobante" required>
                            </div>
                            <div class="form-group">
                                <label>Fecha *</label>
                                <input type="datetime-local" id="fecha" name="fecha" value="<?php echo date('Y-m-d\TH:i'); ?>" required>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>Estado</label>
                                <select id="estado" name="estado">
                                    <option value="Pendiente">Pendiente</option>
                                    <option value="Pagada">Pagada</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Impuesto (%)</label>
                                <input type="number" id="impuesto" name="impuesto" value="18" min="0" max="100" step="0.01">
                            </div>
                        </div>
                    </div>

                    <!-- Artículos -->
                    <div class="form-section">
                        <div class="items-section">
                            <div class="items-header">
                                <h3>🛒 Artículos de la Factura</h3>
                                <button type="button" class="btn-add-item" onclick="agregarArticulo()">
                                    ➕ Agregar Artículo
                                </button>
                            </div>
                            <table class="items-table">
                                <thead>
                                    <tr>
                                        <th>Artículo</th>
                                        <th>Cantidad</th>
                                        <th>Precio</th>
                                        <th>Descuento</th>
                                        <th>Subtotal</th>
                                        <th>Acción</th>
                                    </tr>
                                </thead>
                                <tbody id="itemsTable">
                                    <!-- Los artículos se agregarán dinámicamente aquí -->
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- Totales -->
                    <div class="totals-section">
                        <div class="totals-row">
                            <span>Subtotal:</span>
                            <span id="subtotal">$0.00</span>
                        </div>
                        <div class="totals-row">
                            <span>Descuento:</span>
                            <span id="totalDescuento">$0.00</span>
                        </div>
                        <div class="totals-row">
                            <span>Impuesto (18%):</span>
                            <span id="totalImpuesto">$0.00</span>
                        </div>
                        <div class="totals-row total-final">
                            <span>TOTAL:</span>
                            <span id="totalFinal">$0.00</span>
                        </div>
                    </div>
                </form>
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-large" onclick="cerrarModal()">
                    ❌ Cancelar
                </button>
                <button type="button" class="btn btn-primary btn-large" onclick="guardarFactura()">
                    💾 Guardar Factura
                </button>
            </div>
        </div>
    </div>

    <!-- Modal Ver Factura -->
    <div id="modalVerFactura" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>👁️ Ver Factura</h2>
                <span class="close" onclick="cerrarModalVer()">&times;</span>
            </div>
            <div class="modal-body" id="contenidoFactura">
                <!-- Contenido se carga dinámicamente -->
            </div>
        </div>
    </div>

    <script>
        // Datos PHP para JavaScript
        const articulos = <?php echo json_encode($articulos); ?>;
        
    </script>
    <script src="./gestion_facturas.js"></script>

</body>
</html>